export class Account {

    accountId:number;
	name:String;
	balance:number;
	dob:String;
	accountCreationDate:String;
	accountType:String;
	address:String;
	city:String;
	phone:String;
	email:String;

}